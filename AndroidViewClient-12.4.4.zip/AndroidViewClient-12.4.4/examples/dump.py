#! /usr/bin/env python

print '''
Notice:
-------
'dump.py' was moved to the 'tools' directory and renamed 'dump'.
A simpler example is now in 'dump-simple.py'.

'''
